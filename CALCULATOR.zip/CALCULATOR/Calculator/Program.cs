﻿// See https://aka.ms/new-console-template for more information
using  ArithmeticCalculator;
using static ArithmeticCalculator.Class1;
using static ScientificCalculator.Class1;

namespace calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator calculator = new Calculator();

            {
                Console.WriteLine("Choose an operation:");
                Console.WriteLine("1. Addition (+)");
                Console.WriteLine("2. Subtraction (-)");
                Console.WriteLine("3. Multiplication (*)");
                Console.WriteLine("4. Division (/)");
                Console.WriteLine("5. Square");
                Console.WriteLine("6. Square Root");
                Console.WriteLine("7. Cube");
                Console.WriteLine("8. Cube Root");
                Console.WriteLine("9. x^y");
                Console.WriteLine("10. x^(1/y)");
                Console.Write("Enter your choice (1/2/3/4/5/6/7/8/9/10/11): ");
                string choice = Console.ReadLine();
                double result = 0;
                
                switch (choice)
                {
                    case "1":
                        Console.Write("Enter the first number: ");
                        double num1 = double.Parse(Console.ReadLine());

                        Console.Write("Enter the second number: ");
                        double num2 = double.Parse(Console.ReadLine());
                        result = calculator.Add(num1, num2);
                        break;
                    case "2":
                        Console.Write("Enter the first number: ");
                        double num3 = double.Parse(Console.ReadLine());

                        Console.Write("Enter the second number: ");
                        double num4 = double.Parse(Console.ReadLine());
                        result = calculator.Subtract(num3, num4);
                        break;
                    case "3":
                        Console.Write("Enter the first number: ");
                        double num5 = double.Parse(Console.ReadLine());

                        Console.Write("Enter the second number: ");
                        double num6 = double.Parse(Console.ReadLine());
                        result = calculator.Multiply(num5, num6);
                        break;
                    case "4":
                        Console.Write("Enter the first number: ");
                        double num7 = double.Parse(Console.ReadLine());

                        Console.Write("Enter the second number: ");
                        double num8 = double.Parse(Console.ReadLine());
                        result = calculator.Divide(num7, num8);
                        break;
                    case "5":
                        Console.Write("Enter a number: ");
                        double number = double.Parse(Console.ReadLine());
                        result = Square(number);
                        break;
                    case "6":
                        Console.Write("Enter a number: ");
                        number = double.Parse(Console.ReadLine());
                        result = SquareRoot(number);
                        break;
                    case "7":
                        Console.Write("Enter a number: ");
                        number = double.Parse(Console.ReadLine());
                        result = Cube(number);
                        break;
                    case "8":
                        Console.Write("Enter a number: ");
                        number = double.Parse(Console.ReadLine());
                        result = CubeRoot(number);
                        break;
                    case "9":
                        Console.Write("Enter base (x): ");
                        double x = double.Parse(Console.ReadLine());
                        Console.Write("Enter exponent (y): ");
                        double y = double.Parse(Console.ReadLine());
                        result = Power(x, y);
                        break;
                    case "10":
                        Console.Write("Enter base (x): ");
                        x = double.Parse(Console.ReadLine());
                        Console.Write("Enter root (1/y): ");
                        double root = double.Parse(Console.ReadLine());
                        result = PowerWithRoot(x, root);
                        break;
                    case "11":
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }

                Console.WriteLine("Result: " + result);
            }
        }
    }
}





    
       