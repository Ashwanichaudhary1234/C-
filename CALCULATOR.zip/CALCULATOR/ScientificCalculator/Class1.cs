﻿namespace ScientificCalculator
{
    public class Class1
    {
       
        
        public static double Square(double x)
        {
            return Math.Pow(x, 2);
        }

        public static double SquareRoot(double x)
        {
            return Math.Sqrt(x);
        }

        public static double Cube(double x)
        {
            return Math.Pow(x, 3);
        }

        public static double CubeRoot(double x)
        {
            return Math.Pow(x, 1.0 / 3);
        }

        public static double Power(double x, double y)
        {
            return Math.Pow(x, y);
        }

        public static double PowerWithRoot(double x, double root)
        {
            return Math.Pow(x, 1.0 / root);
        }
    }

}
