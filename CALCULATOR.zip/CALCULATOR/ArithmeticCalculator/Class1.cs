﻿namespace ArithmeticCalculator
{
    public class Class1
    {
        public class Calculator
        {
            public double Add(double num1, double num2)
            {
                return num1 + num2;
            }

            public double Subtract(double num1, double num2)
            {
                return num1 - num2;
            }

            public double Multiply(double num1, double num2)
            {
                return num1 * num2;
            }

            public double Divide(double num1, double num2)
            {
                if (num2 == 0)
                {
                    Console.WriteLine("Cannot divide by zero.");
                    return double.NaN;
                }
                return num1 / num2;
            }
            public double Modulus(double num1, double num2)
            {
                if (num2 == 0)
                {
                    Console.WriteLine("Cannot perform modulus with zero as the divisor.");
                    return double.NaN;
                }
                return num1 % num2;
            }
        }

       
    }

}
