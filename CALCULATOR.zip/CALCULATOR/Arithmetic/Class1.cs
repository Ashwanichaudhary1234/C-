﻿namespace Arithmetic
{
    public class Class1
    {

    }
}