﻿namespace Power
{
    public class Class1
    {

    }
}